# UI Ads General Agent Directives
Protects definitions and metadata models for the Advertising Subsystem.
