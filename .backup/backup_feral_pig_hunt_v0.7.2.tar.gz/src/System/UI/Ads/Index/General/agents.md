# UI Ads Index General Agent Directives
Protects state definitions and reason enumerations for ad coordinator triggers.
