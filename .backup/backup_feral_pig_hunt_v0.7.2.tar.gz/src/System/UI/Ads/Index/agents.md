# UI Ads Index Agent Directives
Protects the master routing logic for advertisements across Start Game and Play Again lifecycle events.
