# UI Ads Agent Directives
Protects the Advertising Subsystem of Feral Pig Hunt.
- Full page interstitial ad supporting free play for gamers.
- Revive Adserver integration v6.0.8 asynchronous script tag.
- 30-second countdown timer, with Skip Ad button emerging after 15 seconds.
- Background scene: Pepperoni pizza with vegetable toppings on a wooden table, and arcade computers with players on the horizon.
