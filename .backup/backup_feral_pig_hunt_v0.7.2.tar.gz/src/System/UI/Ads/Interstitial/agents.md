# Interstitial Ad Agent Directives
Protects the full-page Interstitial Ad component.
- Enforces exact Revive Adserver zone id "13" and delivery script.
- 30-second countdown with Skip button appearing after 15 seconds.
- Renders the pepperoni & vegetable pizza, wooden table, and arcade computers/players background.
