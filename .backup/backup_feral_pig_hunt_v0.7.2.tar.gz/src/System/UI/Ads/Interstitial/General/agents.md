# Interstitial Ad General Agent Directives
Protects mathematical timing formulas and Revive Adserver v6.0.8 configurations for the interstitial ad.
- TOTAL_DURATION_SECONDS: 30
- SKIP_THRESHOLD_SECONDS: 15
- Zone ID "13"
