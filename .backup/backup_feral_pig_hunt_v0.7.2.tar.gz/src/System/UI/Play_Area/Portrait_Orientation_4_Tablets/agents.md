# Tablet Portrait Orientation Agent Directives
Dedicated component for tablets held in portrait orientation.
- Features balanced 20% horizontal side bezels and centered vertical 60% arcade game screen.
- Left bezel: Handcrafted retro robot carrying a plate of pepperoni pizza.
- Right bezel: Newly planted tree with supportive wooden stake.
- Background: Green horizon landscape and starry celestial sky.
- Free of coin slot and speaker clutter.
- Dual input: Supports physical keyboard (desktop keys: arrows/WASD, Space, Shift+7 ampersand pause) AND full bottom touchscreen arcade deck with 4 dedicated buttons.
- Landscape play area remains completely unaltered.
