# Tablet Portrait Orientation General Agent Directives
Maintains the mathematical scaling, 20% side bezel calculation formulas, and backdrop star generation logic for tablets.
- Zero hardcoded pixel assumptions.
- Pure geometric bounding functions.
