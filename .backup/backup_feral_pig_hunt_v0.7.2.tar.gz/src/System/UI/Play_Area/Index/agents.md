# Play Area Index Agent Directives
Coordinating module for the game play area.
- Exclusively routes mobile phones held in portrait mode to the vertical phone view (`Portrait_Orientation_4_Mobile_Phones/`).
- Exclusively routes tablets held in portrait mode to the tablet view (`Portrait_Orientation_4_Tablets/`) with 20% side bezels and dual input.
- Under NO circumstances alter the design or behavior of the landscape view.
- Desktop and laptop computers must continue using physical keyboard input; no point-and-click mouse controls.
