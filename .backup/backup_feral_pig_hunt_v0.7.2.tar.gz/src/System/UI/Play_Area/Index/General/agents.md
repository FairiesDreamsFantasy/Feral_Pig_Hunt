# Play Area Index General Agent Directives
Maintains the deterministic detection heuristics between portrait mobile phones and landscape/desktop systems.
- Zero pseudoscience or arbitrary guesses.
- Evaluates screen aspect ratio and touch capabilities cleanly.
