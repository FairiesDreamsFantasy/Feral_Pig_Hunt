# Portrait Orientation General Agent Directives
Maintains the mathematical scaling, safe area bounds, and 3:4 virtual resolution constants for portrait arcade mode.
- Calculations must remain pure functions.
- Zero hardcoding of pixel dimensions.
