# Portrait Orientation Play Area Agent Directives
This component is dedicated exclusively to mobile phones held in portrait orientation.
- Renders a true vertical arcade screen with aspect-ratio-bound canvas on top.
- Renders the 4 physical-style touchscreen arcade buttons strictly below the screen:
  1. Left Arrow
  2. Right Arrow
  3. Pause / Resume (Shift+7 toggle)
  4. Fire Laser
- Do NOT add mouse point-and-click logic to desktop play.
- Landscape play area design must remain completely unaltered.
