# Agents Directive: Keyboards Engine Language Bindings Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
Language specific input polling, interrupt bindings, and command logs must remain fully written and preserved.
