# Agents Directive: Visuals Engine Language Bindings Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
Language specific rendering modes and direct pixel plots must remain fully written and preserved.
