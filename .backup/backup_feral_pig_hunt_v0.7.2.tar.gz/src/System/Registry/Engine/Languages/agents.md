# Agents Directive: Languages Registry Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
The active programming language settings, compiler flags, and formatting switches must remain fully preserved.
