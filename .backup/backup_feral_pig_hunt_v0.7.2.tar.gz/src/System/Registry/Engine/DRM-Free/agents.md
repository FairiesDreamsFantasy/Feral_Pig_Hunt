# Agents Directive: DRM-Free Registry Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
The DRM-Free visual port selection registries, bandwidth boost configs, and permissive sharing flags must remain fully preserved.
