# Agents Directive: OS Registry Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
The active OS targets, secure boot overrides, and virtual interrupt flags must remain fully preserved.
