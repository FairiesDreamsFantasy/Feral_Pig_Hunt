# Keyboards and Controllers Registry Agent Directives
Aggregates registry nodes for controllers and keyboards:
- Touchscreen (Mobile Phones in Portrait Mode exclusively)
All controller registries must remain preserved and protected.
