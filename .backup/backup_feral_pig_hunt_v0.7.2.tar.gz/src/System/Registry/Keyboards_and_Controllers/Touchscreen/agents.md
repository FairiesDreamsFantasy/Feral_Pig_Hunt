# Touchscreen Registry Agent Directives
Protects the registry metadata and contracts for the touchscreen subsystem.
- Do not remove or stub entries.
- Maintain accurate mapping of physical mobile buttons to game engine events.
