# Touchscreen Registry General Agent Directives
Protects the registry metadata for general touchscreen button specifications.
