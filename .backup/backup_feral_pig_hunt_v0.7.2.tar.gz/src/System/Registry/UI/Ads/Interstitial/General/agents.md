# Ads Interstitial General Registry Agent Directives
Protects specifications, zone IDs, timers, and styling references for the Interstitial Ad.
