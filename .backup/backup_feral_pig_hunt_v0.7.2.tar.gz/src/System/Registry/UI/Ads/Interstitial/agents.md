# Ads Interstitial Master Registry Agent Directives
Protects the Interstitial Ad Registry Node and its submodules.
