# Ads General Registry Agent Directives
Protects general metadata models for the Ads Subsystem.
