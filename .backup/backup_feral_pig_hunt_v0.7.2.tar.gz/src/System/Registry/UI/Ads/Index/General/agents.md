# Ads Index General Registry Agent Directives
Protects reason codes and event metadata for the Ads Index registry.
