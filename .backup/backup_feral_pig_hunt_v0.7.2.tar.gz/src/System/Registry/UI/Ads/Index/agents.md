# Ads Index Master Registry Agent Directives
Protects the Index module metadata for the Ads registry.
