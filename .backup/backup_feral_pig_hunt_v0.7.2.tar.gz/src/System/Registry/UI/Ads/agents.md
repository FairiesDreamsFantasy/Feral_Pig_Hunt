# Ads UI Registry Agent Directives
Master registry directives for UI Advertisements.
- Protects General, Index, and Interstitial registry branches.
