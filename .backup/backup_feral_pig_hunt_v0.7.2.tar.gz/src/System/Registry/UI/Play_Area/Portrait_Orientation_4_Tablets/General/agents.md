# Tablet Play Area Registry General Agent Directives
Registry metadata directives for General specifications of Tablet Portrait Play Area.
- Protect all constants and dual input references.
