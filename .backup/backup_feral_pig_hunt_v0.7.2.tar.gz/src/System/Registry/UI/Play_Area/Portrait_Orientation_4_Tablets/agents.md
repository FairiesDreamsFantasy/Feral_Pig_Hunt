# Tablet Play Area Registry Agent Directives
Registry node preserving metadata for the Tablet Portrait Play Area.
- Protect the 20% side bezel specifications (Robot with pizza, newly planted tree).
- Protect dual input registrations (physical keyboard and touch deck).
