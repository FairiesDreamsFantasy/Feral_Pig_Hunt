# Play Area Registry Aggregator Agent Directives
Aggregates registry nodes for Play Area subcomponents:
- Play_Area/Index/ (Adaptive coordinator)
- Play_Area/Portrait_Orientation_4_Mobile_Phones/ (Mobile vertical view)
All registrations must remain intact and protected.
