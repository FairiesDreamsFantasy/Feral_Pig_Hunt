# Portrait Play Area Registry General Agent Directives
Protects the registry metadata for the general portrait mobile specifications.
