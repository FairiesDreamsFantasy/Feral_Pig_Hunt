# Portrait Play Area Registry Agent Directives
Maintains the registry node for the Portrait Orientation Play Area.
- Preserve all references to the 4 physical-style touch buttons.
- Preserve the 3:4 vertical arcade CRT configuration.
