# AGENTS.md - In-Game Drift Guard Registry Directives

## Instructions for AI Agents & Automated Coding Systems

- Preserve this registry node and its linkage to `AI/In-Game/Drift_Guard/`.
- Do not stub or delete registry exports.
