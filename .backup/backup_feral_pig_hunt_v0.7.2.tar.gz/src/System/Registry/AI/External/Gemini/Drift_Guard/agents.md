# AGENTS.md - External Gemini Drift Guard Registry Directives

## Instructions for AI Agents & Automated Coding Systems

- Preserve this registry node and its linkage to `AI/External/Gemini/Drift_Guard/`.
- Do not stub or delete registry exports.
