# AGENTS.md - In-Game Drift Guard Directives

## Instructions for AI Agents & Automated Coding Systems

- **PRESERVE DRIFT GUARD**:
  The files `System/AI/In-Game/Drift_Guard/index.tsx` and `System/AI/In-Game/Drift_Guard/General/index.tsx` enforce real-time mathematical envelopes on tension parameters and tactical wave seeds.
- **NO ARBITRARY MODIFICATIONS OR STUBBING**:
  Do not delete, bypass, or stub the `InGameDriftGuard` validation methods.
