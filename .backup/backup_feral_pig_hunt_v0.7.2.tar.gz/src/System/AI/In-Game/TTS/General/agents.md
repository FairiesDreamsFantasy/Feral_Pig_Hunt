# <div align="center">FERAL PIG HUNT — AGENT DIRECTIVE</div>
<div align="center">
### SYSTEM/AI/IN-GAME/TTS/GENERAL CODE PRESERVATION AND INTEGRITY MANDATE
</div>

## 1. Safety & Stability Policy
This directory and all of its contents are protected under the **Code Preservation Directive**. Absolutely no unsolicited, arbitrary, or automated simplifications, deletion of functionality, or "TODO" stubbing may occur within this workspace.

## 2. Integrity Protections
* **Speech System Catalog Completeness**: Maintain the full configurations for all speech systems without omission.
* **Volume Attenuation Constants**: Preserve `relativeVolume: 0.80` ensuring TTS speech remains 20% lower than sounds.
* **Prohibition of Babylonian Shortcuts**: Maintain 100% code completion and high-craftsmanship standards. Do not resort to cheap or rushed refactoring.

## 3. Agent Execution Rule
Any AI agent or tool processing these files must execute with 100% precision. Respect the user's intent as the absolute ceiling of functional scope. Maintain security, mathematical logic, and original game craftsmanship intact.
