# <div align="center">FERAL PIG HUNT — AGENT DIRECTIVE</div>
<div align="center">
### SYSTEM/AI/IN-GAME/TTS CODE PRESERVATION AND INTEGRITY MANDATE
</div>

## 1. Safety & Stability Policy
This directory and all of its contents are protected under the **Code Preservation Directive**. Absolutely no unsolicited, arbitrary, or automated simplifications, deletion of functionality, or "TODO" stubbing may occur within this workspace.

## 2. Integrity Protections
* **Speech System Preservation**: Preserve the dedicated catalog of selectable speech systems (`Arcade Announcer`, `Cybernetic`, `Tactical AI`, `Retro Vox`, and `Off`).
* **Tactical Score and Wave Announcements**: Maintain interval-based wave completion announcements with score reporting and player page voice swapping.
* **Volume Attenuation Standard**: Preserve the 20% lower speech attenuation constraint against sound effects.
* **Prohibition of Babylonian Shortcuts**: Maintain 100% code completion and high-craftsmanship standards. Do not resort to cheap or rushed refactoring.

## 3. Agent Execution Rule
Any AI agent or tool processing these files must execute with 100% precision. Respect the user's intent as the absolute ceiling of functional scope. Maintain security, mathematical logic, and original game craftsmanship intact.
