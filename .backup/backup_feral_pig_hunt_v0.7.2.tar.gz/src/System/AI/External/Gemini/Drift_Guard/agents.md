# AGENTS.md - External Gemini Drift Guard Directives

## Instructions for AI Agents & Automated Coding Systems

- **PRESERVE DRIFT GUARD**:
  The files `System/AI/External/Gemini/Drift_Guard/index.tsx` and `System/AI/External/Gemini/Drift_Guard/General/index.tsx` enforce real-time generative payload schema validation, latency thresholds, and Drifts_Found telemetry logging.
- **ZERO API KEY LEAK DIRECTIVE**:
  Under no circumstances may raw API keys or secrets be written to logs or storage. Only non-sensitive key character counts and Google token formats are audited.
- **MANDATORY HUMAN REVIEW**:
  All flagged drift records logged to `Drifts_Found/` are designated for mandatory non-negotiable review by Google Gemini developers.
