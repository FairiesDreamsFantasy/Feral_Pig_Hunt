# <div align="center">FERAL PIG HUNT — AGENT DIRECTIVE</div>
<div align="center">
### CODE PRESERVATION AND INTEGRITY MANDATE
</div>

## 1. Safety & Stability Policy
This directory and all of its contents are protected under the **Code Preservation Directive**. Absolutely no unsolicited, arbitrary, or automated simplifications, deletion of functionality, or "TODO" stubbing may occur within this workspace.

## 2. Integrity Protections
* **Math and Physics Preservation**: This folder contains delicate equations, precise physical constants, or complex coordinate models (including Mass-Spring-Damper controllers, Relativistic Starfield transformations, and spatial FM sound synthesis). Any modification must preserve the mathematical integrity of these systems.
* **No Code Truncation**: Every function, file, and export must remain fully implemented. Do not replace fully featured logic with placeholder stubs.
* **Prohibition of Babylonian Shortcuts**: Maintain 100% code completion and high-craftsmanship standards. Do not resort to cheap or rushed refactoring.

## 3. Agent Execution Rule
Any AI agent or tool processing these files must execute with 100% precision. Respect the user's intent as the absolute ceiling of functional scope. Maintain security, mathematical logic, and original game craftsmanship intact.
