# Agents Directive: Sound Engine Language Bindings Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
Language specific audio synthesis and driver abstractions must remain fully written and preserved.
