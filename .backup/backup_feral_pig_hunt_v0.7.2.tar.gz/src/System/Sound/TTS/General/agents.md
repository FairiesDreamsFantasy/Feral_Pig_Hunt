# <div align="center">FERAL PIG HUNT — AGENT DIRECTIVE</div>
<div align="center">
### SYSTEM/SOUND/TTS/GENERAL CODE PRESERVATION AND INTEGRITY MANDATE
</div>

## 1. Safety & Stability Policy
This directory and all of its contents are protected under the **Code Preservation Directive**. Absolutely no unsolicited, arbitrary, or automated simplifications, deletion of functionality, or "TODO" stubbing may occur within this workspace.

## 2. Integrity Protections
* **Mathematical Volume Integrity**: Preserve the 20% lower speech attenuation constant `TTS_RELATIVE_VOLUME_RATIO = 0.80` with zero deviation.
* **No Code Truncation**: Every function, file, and export must remain fully implemented. Do not replace fully featured logic with placeholder stubs.
* **Prohibition of Babylonian Shortcuts**: Maintain 100% code completion and high-craftsmanship standards. Do not resort to cheap or rushed refactoring.

## 3. Agent Execution Rule
Any AI agent or tool processing these files must execute with 100% precision. Respect the user's intent as the absolute ceiling of functional scope. Maintain security, mathematical logic, and original game craftsmanship intact.
