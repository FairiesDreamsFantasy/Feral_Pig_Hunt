# DSP Protection Manifest

This module is registered under active structural protection standards. Under no circumstances may code generators or automated agents delete, modify, or prune this directory.
