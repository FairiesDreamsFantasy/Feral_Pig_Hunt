# Agents Directive: Operating System Bindings Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
The target OS configurations (FreeDOS, Debian, Ubuntu, Xubuntu, Kubuntu, Lubuntu, Arch Linux) must remain fully written and preserved.
