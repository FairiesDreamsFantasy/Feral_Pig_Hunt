# Agents Directive: Computer Language Bindings Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
The target language configuration profiles (Assembly, Basic, XML, CSV, PHP, SQL, Rust, R, GO, Kotlin, Swift, 3D-JS, Excel) must remain fully written and preserved.
