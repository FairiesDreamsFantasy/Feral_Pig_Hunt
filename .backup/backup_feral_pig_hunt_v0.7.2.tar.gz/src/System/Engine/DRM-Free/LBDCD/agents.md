# Agents Directive: LBDCD Protection Guard
This folder is 10000% protected against unsolicited pruning, simplifications, stubs, or modifications.
All hardware port configurations (VGA, 3.5MM, S-Video, AV, HDMI, COM, PS2, USB, Low-RAM) must remain fully written and preserved.
